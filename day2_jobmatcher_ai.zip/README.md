# 🤖 AI Job Matcher

This is a Streamlit app that takes a resume as input and suggests matching job roles, key strengths, and missing skills using OpenAI's GPT model.

## 🚀 How to Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

Make sure to add your OpenAI API key as a secret:
- In `.streamlit/secrets.toml`
```toml
OPENAI_API_KEY = "your-api-key-here"
```