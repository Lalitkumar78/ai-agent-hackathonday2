
import streamlit as st
import openai

st.set_page_config(page_title="AI Job Matcher", layout="centered")

st.title("🔍 AI Job Matcher")
st.write("Paste your resume below and get personalized job suggestions based on your skills!")

openai.api_key = st.secrets.get("OPENAI_API_KEY", "")

resume_text = st.text_area("📄 Paste Your Resume Here", height=300)

if st.button("Get Job Matches"):
    if not resume_text.strip():
        st.warning("Please paste your resume to continue.")
    else:
        with st.spinner("Analyzing your resume with AI..."):
            prompt = f"Based on the following resume, suggest top 3 job roles that suit the candidate. Also mention top skills and missing skills:

{resume_text}"
            try:
                response = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.7,
                    max_tokens=500
                )
                st.success("Here's what we found:")
                st.markdown(response.choices[0].message.content)
            except Exception as e:
                st.error(f"Error: {e}")
